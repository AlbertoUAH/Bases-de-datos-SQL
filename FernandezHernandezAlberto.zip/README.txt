En caso de querer abrir los diagramas, tanto Entidad-Relacion como Relacional, ir a la siguiente pagina:

https://app.diagrams.net/

- Seleccionar "Open Existing Diagram"
- Seleccionar el fichero